# Reproducibility Package: Datasets and Evaluation Benchmarks
## OT Vulnerability Risk Analysis and Prioritisation — Hybrid Agentic RAG-Enabled OT Cybersecurity Compliance Solution

**Version:** 3.0  
**Author:** Porwal, Mohit  
**Affiliation:** Liverpool John Moores University (LJMU)  
**Thesis title:** Development of a Hybrid Agentic RAG-Enabled Solution for OT Cybersecurity Compliance with IEC 62443 and NIST SP 800-82  
**Date:** April 2026

---

## 1. Package Purpose

This package is a thesis reproducibility package. It contains the datasets, benchmarks, evaluation outputs, and supporting documentation used to implement and evaluate the bounded service **OT Vulnerability Risk Analysis and Prioritisation** within a four-layer Hybrid Agentic RAG-enabled OT cybersecurity compliance architecture.

The package is intended to support:
- inspection of the structured operational inputs used by the prototype;
- replication of the end-to-end operational analysis workflow and prioritisation results;
- review of the 15-case deterministic benchmark expectations and run outputs;
- review of the 22-query RAG/agentic benchmark, RAGAS-aligned scores, and leakage-audit structure;
- verification of file provenance, schema descriptions, and integrity metadata; and
- reproduction of the RAGAS-aligned evaluation using the provided scoring script.

---

## 2. What This Package Is and Is Not

This release should be interpreted as a **reproducibility package** rather than a field-collected dataset or a live enterprise deployment export. Specifically:

- It **is** a structured collection of operational inputs, application-generated outputs, researcher-curated benchmark artefacts, and supporting documentation for a bounded MSc research prototype.
- It **is not** a field-collected ICS incident repository, a live SOC export, a claim of enterprise-scale production deployment, or an externally collected public benchmark corpus.

The benchmark files are **researcher-curated evaluation artefacts derived from the study context and finalised for thesis evaluation**. They should be interpreted as architecture-matched validation instruments rather than population-representative OT datasets.

---

## 3. Architecture Summary

The implemented prototype uses a four-layer Hybrid Agentic RAG architecture:

| Layer | Name | Role |
|---|---|---|
| Layer 1 | Data Ingestion and Preparation Layer | Ingests, normalises, and correlates OT vulnerability and asset evidence |
| Layer 2 | Hybrid Agentic RAG Layer | NIST SP 800-82 retrieval (940 chunks, 1,000 chars / 200-char overlap, Top-5 cosine similarity, temperature 0.0) + Gemini 1.5 Pro orchestration with function calling |
| Layer 3 | Deterministic OT Logic Tool Layer | Explicit rule-based evaluation: likelihood, impact, SSVC-adapted priority, action, residual risk, HITL routing (custom TypeScript module) |
| Layer 4 | Governance and Release Layer | Always invoked — mandatory HITL validation and curated IEC 62443 alignment outside the AI corpus on every output |

**IP-safe standards handling:** Public NIST SP 800-82 guidance is the sole standards corpus inside the AI boundary. IEC 62443 text is intentionally excluded from all AI processing and is aligned only through curated control-reference mappings under mandatory human review.

---

## 4. Folder Structure

```
zenodo_ready_thesis_datasets_package_v3/
│
├── 00_documentation/           ← Start here
│   ├── README.md               ← This file
│   ├── PROVENANCE.md           ← Detailed provenance and construction notes
│   ├── MANIFEST.csv            ← All files with size, provenance, and description
│   ├── CHECKSUMS.sha256        ← SHA-256 hashes for integrity verification
│   ├── .zenodo.json            ← Zenodo metadata (title, creator, licence)
│   ├── CITATION.cff            ← Machine-readable citation metadata
│   ├── EXTERNAL_DEPENDENCIES.md← Excluded and externally cited materials
│   ├── UPLOAD_INSTRUCTIONS.md  ← Step-by-step Zenodo upload guide
│   ├── DATA_DICTIONARY_*.csv   ← Column-level schema for each data file
│   └── dataset_relationships_workflow.svg ← Visual dataset-to-purpose map
│
├── 01_operational_inputs/      ← User-provided; unchanged from prototype run
│   ├── ot_vulnerability_export.xlsx
│   └── ot_asset_inventory.xlsx
│
├── 02_operational_outputs/     ← Application-generated
│   └── ot_prioritized_analysis_results.xlsx
│
├── 03_deterministic_validation/← Benchmark + execution outputs
│   ├── ot_vulnerability_gold_benchmark_15_cases.xlsx
│   └── deterministic_benchmark_run_outputs.csv
│
├── 04_rag_agentic_evaluation/  ← Benchmark + scores + leakage audit + script
│   ├── rag_agentic_gold_benchmark_22_queries.xlsx
│   ├── rag_agentic_run_outputs_supporting_text.csv
│   ├── rag_agentic_scoring_and_leakage_audit_pack.xlsx
│   ├── ragas_evaluation_results_final.csv   ← NEW in v3: per-query RAGAS scores
│   └── ragas_eval.py                        ← NEW in v3: reproducible scoring script
│
└── 05_supplementary_documentation/
    ├── dataset_mapping_and_provenance_section.pdf
    └── key_findings_input_output_comparison.docx
```

---

## 5. How to Use This Package

### Step 1 — Understand the data flow
Read `PROVENANCE.md` and `dataset_relationships_workflow.svg` to understand how the files relate to each other and to the four-layer prototype architecture.

### Step 2 — Inspect operational inputs
Open `01_operational_inputs/ot_vulnerability_export.xlsx` and `ot_asset_inventory.xlsx`. These are the user-provided OT case inputs. Schema is in `00_documentation/DATA_DICTIONARY_operational_inputs_*.csv`.

### Step 3 — Review operational outputs
Open `02_operational_outputs/ot_prioritized_analysis_results.xlsx`. This is the application-generated prioritisation output — the principal evidence for the end-to-end evaluation in Chapter 5. Schema is in `DATA_DICTIONARY_operational_outputs_prioritized_results.csv`.

### Step 4 — Review deterministic validation
Open `03_deterministic_validation/ot_vulnerability_gold_benchmark_15_cases.xlsx` alongside `deterministic_benchmark_run_outputs.csv`. The run output CSV shows predicted vs expected labels for all 15 cases. Every row should show Match=Yes (15/15 exact agreement). Schema is in `DATA_DICTIONARY_deterministic_validation.csv`.

### Step 5 — Review RAG/agentic evaluation
Open `04_rag_agentic_evaluation/rag_agentic_gold_benchmark_22_queries.xlsx` to inspect the 22 benchmark queries and gold reference answers. Open `ragas_evaluation_results_final.csv` to inspect the per-query RAGAS-aligned scores. Open `rag_agentic_scoring_and_leakage_audit_pack.xlsx` to inspect the leakage audit and scoring workbook structure.

### Step 6 — Reproduce RAGAS scores
Run `ragas_eval.py` with your application run outputs and the gold benchmark CSV to reproduce or extend the RAGAS-aligned evaluation. See the script header for usage instructions. Requires: `ragas`, `langchain-google-genai`, `pandas`.

### Step 7 — Verify integrity
Run SHA-256 checksums against `CHECKSUMS.sha256` to confirm file integrity.

---

## 6. Key Evaluation Results (Chapter 5 Summary)

### Layer A — End-to-End Operational Outcomes (60 cases)
| Metric | Value |
|---|---|
| Total raw vulnerabilities | 60 |
| Priority distribution | ACT: 28 \| ATTEND: 14 \| TRACK: 8 \| ARCHIVE: 10 |
| Compression ratio | 53.3% |
| Contextual de-prioritisation rate | 16.7% (10/60) |
| HITL governance rate | 70.0% (42/60) |
| Mitigation coverage | 100% (50/50 actionable) |
| Cited-control traceability rate | 94.0% (47/50 actionable) |

### Layer B — Deterministic Benchmark (15 cases)
| Output field | Accuracy | Macro F1 | Balanced accuracy |
|---|---|---|---|
| Priority class | 1.00 | 1.00 | 1.00 |
| Final action | 1.00 | 1.00 | 1.00 |
| HITL-required flag | 1.00 | 1.00 | 1.00 |

### Layer C — RAGAS-Aligned Evaluation (22 queries, leakage-clean run)
| Metric | Score (0–1) | Method |
|---|---|---|
| Faithfulness | 0.66 (0.80 in hybrid scenario) | TF-IDF cosine similarity over NIST SP 800-82r3 corpus |
| Answer relevancy | 0.98 | Cosine similarity, query vs answer |
| Context precision | 0.82 | Retrieved chunks vs gold reference |
| Context recall | 0.80 | Gold statements vs retrieved context |
| Tool-call accuracy | 0.91 (20/22) | Actual tool trace vs gold expected tool |

**Comparative result:** Hybrid Agentic RAG (NIST retrieval + deterministic tool output) achieves faithfulness 0.80 vs 0.62 for RAG-only baseline (+0.18 gain) and context recall 0.86 vs 0.73 (+0.14 gain).

### Layer D — HITL and Governance
| Aspect | Result |
|---|---|
| Compliance-flag coverage rate | 94.0% (47/50) |
| Autonomous-release prevention | Confirmed — Layer 4 always invoked without exception |

---

## 7. Standards and IP Handling

- **NIST SP 800-82 Rev. 3** — publicly available grounding corpus used inside the AI boundary. Cited but not redistributed in this package (see `EXTERNAL_DEPENDENCIES.md`).
- **IEC 62443** — intentionally excluded from all AI processing and from this package. Alignment is achieved only through curated control-reference mappings under mandatory human review outside the AI corpus. This preserves the IP-safe standards-handling model required by ISA governing policy (ISA, 2026).

---

## 8. Provenance Summary

| Evidence group | File(s) | Provenance |
|---|---|---|
| Operational inputs | `01_operational_inputs/` | User-provided |
| Operational outputs | `02_operational_outputs/` | Application-generated |
| Deterministic benchmark | `03_deterministic_validation/` | Researcher-curated + application-generated |
| RAG/agentic benchmark | `04_rag_agentic_evaluation/*.xlsx` | Researcher-curated |
| RAGAS scores | `ragas_evaluation_results_final.csv` | Computed — TF-IDF cosine similarity over NIST corpus |
| RAGAS script | `ragas_eval.py` | Author-written reproducibility script |
| Supplementary docs | `05_supplementary_documentation/` | Supplementary narrative artefacts |

---

## 9. Citation

See `CITATION.cff` for machine-readable citation metadata. Suggested citation:

> Porwal, M. (2026) *Reproducibility Package: Datasets and Evaluation Benchmarks for OT Vulnerability Risk Analysis and Prioritisation in a Hybrid Agentic RAG-Enabled OT Cybersecurity Compliance Solution* [Dataset]. Zenodo. doi: 10.5281/zenodo.XXXXXXX

---

## 10. Licence

This package is released under **Creative Commons Attribution 4.0 International (CC BY 4.0)**.  
You are free to share and adapt the material for any purpose, provided appropriate credit is given.  
See `LICENSE.txt` for the full licence text.

**Note:** NIST SP 800-82 is a public-domain document cited but not included. IEC 62443 is excluded. The depositor confirms that all included files are either user-provided operational data or researcher-generated artefacts for which redistribution rights are held.
