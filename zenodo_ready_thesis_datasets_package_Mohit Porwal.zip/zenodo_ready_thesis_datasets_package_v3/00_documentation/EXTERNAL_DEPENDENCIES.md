# External Dependencies and Intentionally Excluded Materials

## 1. Publicly Cited but Not Redistributed

### NIST SP 800-82 Revision 3
- **What it is:** The principal public standards-grounding corpus used inside the AI boundary of the implemented prototype.
- **Why not redistributed:** NIST SP 800-82 is a publicly available document. Redistributing it within this package is unnecessary; users should access it from the official source.
- **Official source:** Stouffer, K., Pease, M., Tang, C.Y., Zimmerman, T., Pillitteri, V., Lightman, S., Hahn, A., Saravia, S., Sherule, A. and Thompson, M. (2023) *Guide to Operational Technology (OT) Security*, NIST Special Publication 800-82 Revision 3. Available at: https://doi.org/10.6028/NIST.SP.800-82r3
- **How it was used:** Chunked into 940 fixed-size segments (1,000 characters with 200-character overlap), embedded using the gemini-embedding-2-preview model, and retrieved using Top-5 cosine similarity for contextual grounding of analytical drafts in the Hybrid Agentic RAG Layer.

### Public Threat Intelligence Sources
- CISA Known Exploited Vulnerabilities (KEV) Catalog — https://www.cisa.gov/known-exploited-vulnerabilities-catalog
- FIRST EPSS (Exploit Prediction Scoring System) — https://www.first.org/epss/
- NIST National Vulnerability Database (NVD) — https://nvd.nist.gov/

These sources informed the vulnerability enrichment attributes in the operational input datasets but are not redistributed here.

---

## 2. Intentionally Excluded — IEC 62443

- **What it is:** The ISA/IEC 62443 series of industrial cybersecurity standards.
- **Why excluded:** IEC 62443 is a proprietary, licensed standard. ISA governing policy explicitly prohibits the entry of ISA intellectual property, including IEC 62443 standards text, into AI tools without express written permission (ISA, 2026). Accordingly, IEC 62443 text was never ingested, embedded, or vectorised within the AI boundary of the prototype. It is excluded from this package entirely.
- **How IEC 62443 alignment was achieved:** Through curated control-reference mappings maintained outside the AI corpus and applied exclusively within the Governance and Release Layer under mandatory Human-in-the-Loop validation. These mappings are represented in the operational output dataset as control-reference identifiers (e.g., "FR3 — System Integrity") rather than as standards text.
- **Reference:** ISA (2026) *Use of AI Tools in ISA Activities* [Policy Statement]. ISA Governing Documents. Available at: https://www.isa.org/about-isa/governing-documents/use-of-ai-tools-in-isa-activities

---

## 3. Excluded for Security and Privacy Reasons

- **Live plant identifiers and IP addresses:** The operational input datasets use representative asset identifiers (e.g., PLC-01, SCADA-PRI) and placeholder IP address ranges. No real plant identifiers, site names, or production network addresses are included.
- **API keys and credentials:** Any API keys, authentication tokens, or access credentials for external enrichment services (EPSS, KEV, vulnerability management platforms) are excluded.
- **Live system access:** The prototype does not require and this package does not include any live plant integration, SCADA system connection, or real-time data feed.
