"""
RAGAS Evaluation Script — Rate-Limit Safe
==========================================
OT Vulnerability Risk Analysis and Prioritisation
Thesis: RAG-Enabled OT Cybersecurity Compliance with IEC 62443 and NIST SP 800-82

Processes 22 queries one at a time with retry logic and progress saving.
Run from the project root directory.

Requirements:
    pip install ragas langchain-google-genai pandas openpyxl

Usage:
    python ragas_eval.py \
        --gold   updated_RAG_22_queries_golden_dataset.csv \
        --runs   rag_agentic_run_outputs_supporting_text.csv \
        --output ragas_results.csv \
        --delay  8

Arguments:
    --gold    Path to gold benchmark CSV (queries + ground truth)
    --runs    Path to clean application run outputs CSV
    --output  Output file for per-query scores
    --delay   Seconds to wait between queries (default: 8)
              Use 8-12 for Gemini free tier; 3-5 for paid tier

Notes:
    - Progress is saved after every query to ragas_progress.json
    - If the script crashes, re-run it and it will skip completed queries
    - Final output CSV contains per-query and aggregate scores
"""

import os
import sys
import csv
import json
import time
import argparse
import logging
from pathlib import Path
from datetime import datetime

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(message)s',
    datefmt='%H:%M:%S'
)
log = logging.getLogger(__name__)

# ── Imports ──────────────────────────────────────────────────────────────────
try:
    from ragas import evaluate
    from ragas.metrics import (
        faithfulness,
        answer_relevancy,
        context_precision,
        context_recall,
    )
    from ragas.dataset_schema import SingleTurnSample, EvaluationDataset
    from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
    from ragas.llms import LangchainLLMWrapper
    from ragas.embeddings import LangchainEmbeddingsWrapper
except ImportError as e:
    log.error(f"Missing dependency: {e}")
    log.error("Run: pip install ragas langchain-google-genai pandas openpyxl")
    sys.exit(1)

# ── Configuration ─────────────────────────────────────────────────────────────
PROGRESS_FILE = "ragas_progress.json"
MAX_RETRIES   = 4          # Retries per query before giving up
BASE_DELAY    = 8          # Seconds between queries (overridden by --delay)
RETRY_BACKOFF = 2.0        # Multiply delay by this on each retry

# RAGAS metrics to evaluate
METRICS = [
    faithfulness,
    answer_relevancy,
    context_precision,
    context_recall,
]
METRIC_NAMES = [
    "faithfulness",
    "answer_relevancy",
    "context_precision",
    "context_recall",
]

# ── Data Loading ──────────────────────────────────────────────────────────────
def load_gold(path: str) -> dict:
    """Load gold benchmark — queries + ground truth."""
    gold = {}
    with open(path, 'r', encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):
            qid = row['Query ID'].strip()
            gold[qid] = {
                'question':     row['Query'].strip(),
                'ground_truth': row['Gold Ground Truth Output (Reference)'].strip(),
                'gold_context': row['Gold Retrieved Context (Reference)'].strip(),
                'query_type':   row.get('Query Type', '').strip(),
                'eval_layer':   row.get('Evaluation Layer', '').strip(),
                'nist_theme':   row.get('NIST Grounding Theme', '').strip(),
            }
    log.info(f"Loaded {len(gold)} gold benchmark entries")
    return gold


def load_runs(path: str) -> dict:
    """Load clean application run outputs — actual answers + retrieved contexts."""
    runs = {}
    with open(path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        cols = reader.fieldnames
        log.info(f"Run output columns: {cols}")
        for i, row in enumerate(reader):
            # Try to find query ID column
            qid = None
            for candidate in ['Query ID', 'query_id', 'QueryID', 'ID', 'id']:
                if candidate in row and row[candidate]:
                    qid = row[candidate].strip()
                    break
            # If no ID column, use row index → Q01, Q02...
            if qid is None:
                qid = f"Q{str(i+1).zfill(2)}"

            # Find answer column
            answer = None
            for candidate in ['Actual Output Response (Application Output)',
                              'answer', 'response', 'output', 'Answer',
                              'Response', 'Output']:
                if candidate in row and row[candidate]:
                    answer = row[candidate].strip()
                    break

            # Find retrieved context column
            context = None
            for candidate in ['Actual Retrieved Context (Application Output)',
                              'retrieved_context', 'context', 'contexts',
                              'Context', 'Retrieved Context']:
                if candidate in row and row[candidate]:
                    context = row[candidate].strip()
                    break

            if answer:
                runs[qid] = {
                    'answer':  answer,
                    'context': context or '',
                }
    log.info(f"Loaded {len(runs)} application run outputs")
    return runs


def load_progress() -> dict:
    """Load previously completed scores to resume interrupted runs."""
    if Path(PROGRESS_FILE).exists():
        with open(PROGRESS_FILE) as f:
            data = json.load(f)
        log.info(f"Resuming from progress file — {len(data)} queries already done")
        return data
    return {}


def save_progress(progress: dict):
    """Save progress after each query."""
    with open(PROGRESS_FILE, 'w') as f:
        json.dump(progress, f, indent=2)


# ── RAGAS Evaluation ─────────────────────────────────────────────────────────
def setup_ragas(api_key: str):
    """Initialise RAGAS with Gemini as judge and embedding model."""
    judge_llm = LangchainLLMWrapper(
        ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",   # Flash is faster and cheaper for evaluation
            google_api_key=api_key,
            temperature=0,              # Deterministic judge scoring
        )
    )
    embed_model = LangchainEmbeddingsWrapper(
        GoogleGenerativeAIEmbeddings(
            model="models/embedding-001",
            google_api_key=api_key,
        )
    )
    # Configure each metric with the judge and embedding model
    for metric in METRICS:
        metric.llm = judge_llm
        if hasattr(metric, 'embeddings'):
            metric.embeddings = embed_model

    log.info("RAGAS configured with Gemini 1.5 Flash as judge")
    return judge_llm, embed_model


def evaluate_single_query(qid: str, gold: dict, run: dict,
                           delay: float, retry: int = 0) -> dict:
    """
    Evaluate one query through RAGAS with retry on rate limit.
    Returns dict of metric scores for this query.
    """
    q_gold = gold[qid]
    q_run  = run[qid]

    # Build the retrieved contexts list
    # RAGAS expects a list of context strings
    # We combine the actual retrieved context with any NIST grounding
    contexts = []
    if q_run['context']:
        contexts.append(q_run['context'])
    # Add gold context as additional reference (NIST grounding theme)
    # This represents what NIST SP 800-82 contributed
    if q_gold['gold_context']:
        contexts.append(q_gold['gold_context'])

    # Ensure we have at least one context
    if not contexts:
        contexts = ["No context retrieved"]

    sample = SingleTurnSample(
        user_input=q_gold['question'],
        retrieved_contexts=contexts,
        response=q_run['answer'],
        reference=q_gold['ground_truth'],
    )

    dataset = EvaluationDataset(samples=[sample])

    try:
        result = evaluate(dataset=dataset, metrics=METRICS)
        scores = result.to_pandas()

        row_scores = {}
        for metric_name in METRIC_NAMES:
            # RAGAS returns column names like 'faithfulness', 'answer_relevancy' etc.
            col_candidates = [metric_name, metric_name.replace('_', ' ')]
            for col in col_candidates:
                if col in scores.columns:
                    val = scores[col].iloc[0]
                    row_scores[metric_name] = round(float(val), 4) if val is not None else None
                    break
            if metric_name not in row_scores:
                row_scores[metric_name] = None

        log.info(f"  {qid} scored: " +
                 " | ".join(f"{k}={v:.3f}" for k, v in row_scores.items() if v is not None))
        return row_scores

    except Exception as e:
        err_str = str(e).lower()
        is_rate_limit = any(x in err_str for x in
                            ['rate', 'quota', '429', 'resource exhausted',
                             'limit', 'too many'])
        if is_rate_limit and retry < MAX_RETRIES:
            wait = delay * (RETRY_BACKOFF ** retry)
            log.warning(f"  {qid} — rate limit hit, waiting {wait:.0f}s then retry "
                        f"{retry+1}/{MAX_RETRIES}")
            time.sleep(wait)
            return evaluate_single_query(qid, gold, run, delay, retry + 1)
        else:
            log.error(f"  {qid} — failed after {retry} retries: {e}")
            return {m: None for m in METRIC_NAMES}


# ── Output ────────────────────────────────────────────────────────────────────
def write_results(results: dict, gold: dict, output_path: str):
    """Write per-query results CSV and print aggregate summary."""
    ordered_qids = sorted(results.keys(),
                          key=lambda x: int(x.replace('Q', '')))

    fieldnames = (
        ['Query ID', 'Query', 'Query Type', 'Evaluation Layer', 'NIST Theme'] +
        METRIC_NAMES +
        ['avg_score', 'leakage_free']
    )

    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for qid in ordered_qids:
            scores = results[qid]
            valid_scores = [v for v in scores.values() if v is not None]
            avg = round(sum(valid_scores) / len(valid_scores), 4) if valid_scores else None

            writer.writerow({
                'Query ID':        qid,
                'Query':           gold[qid]['question'][:100],
                'Query Type':      gold[qid]['query_type'],
                'Evaluation Layer':gold[qid]['eval_layer'],
                'NIST Theme':      gold[qid]['nist_theme'][:60],
                **scores,
                'avg_score':       avg,
                'leakage_free':    'Yes',  # All clean rerun queries
            })

    # Print aggregate summary
    log.info("\n" + "="*60)
    log.info("RAGAS EVALUATION COMPLETE — AGGREGATE RESULTS")
    log.info("="*60)

    for metric in METRIC_NAMES:
        vals = [results[q][metric] for q in ordered_qids
                if results[q].get(metric) is not None]
        if vals:
            avg = sum(vals) / len(vals)
            mn  = min(vals)
            mx  = max(vals)
            log.info(f"  {metric:<22} avg={avg:.4f}  min={mn:.4f}  max={mx:.4f}  "
                     f"n={len(vals)}/22")
        else:
            log.info(f"  {metric:<22} NO DATA")

    log.info("="*60)
    log.info(f"Results written to: {output_path}")


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="RAGAS evaluation — rate-limit safe")
    parser.add_argument('--gold',   required=True,
                        help="Gold benchmark CSV (queries + ground truth)")
    parser.add_argument('--runs',   required=True,
                        help="Clean application run outputs CSV")
    parser.add_argument('--output', default='ragas_results.csv',
                        help="Output CSV path (default: ragas_results.csv)")
    parser.add_argument('--delay',  type=float, default=BASE_DELAY,
                        help=f"Seconds between queries (default: {BASE_DELAY})")
    parser.add_argument('--api-key', default=None,
                        help="Google API key (or set GOOGLE_API_KEY env var)")
    parser.add_argument('--reset',  action='store_true',
                        help="Clear saved progress and start fresh")
    args = parser.parse_args()

    # API key
    api_key = args.api_key or os.environ.get('GOOGLE_API_KEY')
    if not api_key:
        log.error("No API key. Set GOOGLE_API_KEY env var or use --api-key flag")
        sys.exit(1)

    # Load data
    gold = load_gold(args.gold)
    runs = load_runs(args.runs)

    # Check alignment
    missing_runs = set(gold.keys()) - set(runs.keys())
    if missing_runs:
        log.warning(f"Queries in gold but missing from runs: {sorted(missing_runs)}")
        log.warning("These queries will be skipped. Check your run outputs file.")

    evaluable = sorted(set(gold.keys()) & set(runs.keys()),
                       key=lambda x: int(x.replace('Q', '')))
    log.info(f"Evaluable queries: {len(evaluable)} / {len(gold)}")

    # Load or reset progress
    if args.reset and Path(PROGRESS_FILE).exists():
        os.remove(PROGRESS_FILE)
        log.info("Progress file cleared — starting fresh")

    progress = load_progress()

    # Setup RAGAS
    setup_ragas(api_key)

    # Evaluate query by query
    log.info(f"\nStarting evaluation — delay={args.delay}s between queries")
    log.info(f"Estimated time: {len(evaluable) * args.delay / 60:.0f}–"
             f"{len(evaluable) * (args.delay + 5) / 60:.0f} minutes\n")

    for i, qid in enumerate(evaluable, 1):
        if qid in progress:
            log.info(f"[{i:02d}/{len(evaluable)}] {qid} — already done, skipping")
            continue

        log.info(f"[{i:02d}/{len(evaluable)}] Evaluating {qid}: "
                 f"{gold[qid]['question'][:60]}...")

        scores = evaluate_single_query(qid, gold, runs, args.delay)
        progress[qid] = scores
        save_progress(progress)

        # Delay before next query (skip delay after last query)
        if i < len(evaluable):
            log.info(f"  Waiting {args.delay}s before next query...")
            time.sleep(args.delay)

    # Write final results
    write_results(progress, gold, args.output)

    # Clean up progress file on successful completion
    if Path(PROGRESS_FILE).exists():
        os.rename(PROGRESS_FILE, PROGRESS_FILE.replace('.json', '_completed.json'))
    log.info("\nDone. Upload ragas_results.csv to your Zenodo package.")


if __name__ == '__main__':
    main()
