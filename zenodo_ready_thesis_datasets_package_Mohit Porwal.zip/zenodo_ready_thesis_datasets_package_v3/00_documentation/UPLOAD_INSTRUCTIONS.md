# Zenodo Upload Instructions
## MSc Thesis Reproducibility Package — OT Vulnerability Risk Analysis and Prioritisation

**For:** Mohit Porwal, Liverpool John Moores University  
**Package version:** 3.0  
**Date:** April 2026

---

## What Zenodo Is and Why It Is Required

Zenodo (https://zenodo.org) is a free, open research data repository operated by CERN and supported by the European Commission. Many universities, including LJMU, require MSc and PhD students to deposit datasets, benchmark artefacts, and reproducibility materials on Zenodo or an equivalent repository so that:
- examiners can verify empirical claims independently;
- the research community can reproduce and extend the work; and
- the thesis meets open-research and data-management obligations.

This package is your reproducibility deposit. Once uploaded, Zenodo will assign a **DOI** (Digital Object Identifier) that you reference in your thesis (Chapter 5, Section 5.2 and the references list) as:

> Porwal, M. (2026) *Reproducibility Package: Datasets and Evaluation Benchmarks for OT Vulnerability Risk Analysis and Prioritisation in a Hybrid Agentic RAG-Enabled OT Cybersecurity Compliance Solution* [Dataset]. Zenodo. doi: 10.5281/zenodo.XXXXXXX

Replace `XXXXXXX` with the actual Zenodo record ID once uploaded.

---

## Pre-Upload Checklist

Before starting the upload, confirm the following:

- [ ] You hold redistribution rights to all files in the package (no licensed IEC 62443 text is included — confirmed)
- [ ] No sensitive operational plant identifiers, IP addresses, or personal data remain in the files
- [ ] Your name spelling is final: **Porwal, Mohit**
- [ ] Your affiliation is final: **Liverpool John Moores University**
- [ ] The thesis title is final: *Development of a Hybrid Agentic RAG-Enabled Solution for OT Cybersecurity Compliance with IEC 62443 and NIST SP 800-82*
- [ ] The package zip file (`zenodo_ready_thesis_datasets_package_v3.zip`) is complete and all files open correctly
- [ ] You have verified at least one SHA-256 checksum from `CHECKSUMS.sha256`

---

## Step-by-Step Upload Guide

### Step 1 — Create a Zenodo account
Go to https://zenodo.org and sign up (or log in) using your LJMU email or GitHub/ORCID account.

### Step 2 — Start a new upload
Click **"New Upload"** (top right or via the **"+"** button).

### Step 3 — Upload the ZIP file
Drag and drop `zenodo_ready_thesis_datasets_package_v3.zip` into the upload area, or click to browse and select it. Wait for the upload to complete before proceeding.

### Step 4 — Fill in the metadata form

**Resource type:** Dataset

**Title:**  
```
Reproducibility Package: Datasets and Evaluation Benchmarks for OT Vulnerability Risk Analysis and Prioritisation in a Hybrid Agentic RAG-Enabled OT Cybersecurity Compliance Solution
```

**Authors:**  
- Family name: `Porwal`  
- Given name: `Mohit`  
- Affiliation: `Liverpool John Moores University`  
- ORCID: (add if you have one, otherwise leave blank)

**Description (paste exactly):**
```
This reproducibility package accompanies the MSc thesis "Development of a Hybrid Agentic RAG-Enabled Solution for OT Cybersecurity Compliance with IEC 62443 and NIST SP 800-82" (Liverpool John Moores University, 2026).

The package contains: (1) user-provided operational OT input datasets (vulnerability export and asset inventory); (2) application-generated prioritisation outputs; (3) a researcher-curated 15-case deterministic gold benchmark and corresponding run outputs; (4) a researcher-curated 22-query RAG/agentic evaluation benchmark with RAGAS-aligned per-query scores and a reproducible scoring script; and (5) supplementary documentation including provenance notes, data dictionaries, and schema metadata.

The implemented prototype uses a four-layer Hybrid Agentic RAG architecture: Data Ingestion and Preparation Layer, Hybrid Agentic RAG Layer (NIST SP 800-82 grounding, Gemini 1.5 Pro, temperature 0.0), Deterministic OT Logic Tool Layer (SSVC-adapted prioritisation), and Governance and Release Layer (mandatory HITL, always invoked). IEC 62443 text is intentionally excluded from all AI processing in accordance with ISA governing policy. Public NIST SP 800-82 guidance is cited but not redistributed.

Key evaluation results: 53.3% operational compression ratio; 15/15 deterministic benchmark exact match; RAGAS-aligned faithfulness 0.66 (0.80 in hybrid scenario), answer relevancy 0.98, context precision 0.82, context recall 0.80, tool-call accuracy 0.91 (20/22). Hybrid architecture improves faithfulness +0.18 and context recall +0.14 over RAG-only baseline.
```

**Keywords (add each separately):**
- Operational Technology
- OT cybersecurity
- Hybrid Agentic RAG
- Vulnerability prioritisation
- IEC 62443
- NIST SP 800-82
- SSVC
- Deterministic evaluation
- Human-in-the-Loop
- Reproducibility package
- Benchmark
- RAG evaluation

**Licence:** Creative Commons Attribution 4.0 International (CC BY 4.0)

**Access:** Open Access

**Version:** 3.0

**Language:** English

### Step 5 — Related identifiers (optional but recommended)
If your thesis will be deposited separately (e.g. via LJMU's institutional repository), add:
- Relation type: `Is supplemented by`
- Identifier: (thesis DOI or repository URL once available)

### Step 6 — Save and publish
Click **"Save draft"** first to verify the record looks correct. Then click **"Publish"**. 

⚠️ Once published, the record and its DOI are permanent. You can add new versions later but cannot unpublish.

### Step 7 — Record the DOI
Copy the DOI (format: `10.5281/zenodo.XXXXXXX`) and update:
- Chapter 5, Section 5.2, the provenance table — replace "doi:10.5281/zenodo.XXXXXXX"
- Chapter 6, Section 6.3, the second contribution paragraph — replace "Porwal, 2026" reference
- The References section in Chapters 5 and 6

---

## What to Include in Your Thesis

In your thesis, add the following in the appropriate section (Chapter 5, Section 5.3 or the data management statement):

> The operational datasets, benchmark artefacts, evaluation outputs, and reproducibility materials associated with this thesis are publicly available at: Porwal, M. (2026) *Reproducibility Package: Datasets and Evaluation Benchmarks for OT Vulnerability Risk Analysis and Prioritisation in a Hybrid Agentic RAG-Enabled OT Cybersecurity Compliance Solution* [Dataset]. Zenodo. doi: 10.5281/zenodo.XXXXXXX

---

## File Inventory for Upload Verification

The ZIP file should contain exactly these files (22 total data/documentation files):

| Folder | File | Purpose |
|---|---|---|
| 00_documentation | README.md | Main package guide |
| 00_documentation | PROVENANCE.md | Detailed provenance |
| 00_documentation | MANIFEST.csv | File inventory |
| 00_documentation | CHECKSUMS.sha256 | Integrity hashes |
| 00_documentation | .zenodo.json | Zenodo metadata |
| 00_documentation | CITATION.cff | Citation metadata |
| 00_documentation | EXTERNAL_DEPENDENCIES.md | Excluded materials |
| 00_documentation | UPLOAD_INSTRUCTIONS.md | This file |
| 00_documentation | DATA_DICTIONARY_*.csv (×5) | Column schemas |
| 00_documentation | dataset_relationships_workflow.svg | Visual map |
| 01_operational_inputs | ot_vulnerability_export.xlsx | Raw vulnerability data |
| 01_operational_inputs | ot_asset_inventory.xlsx | OT asset context |
| 02_operational_outputs | ot_prioritized_analysis_results.xlsx | Prioritisation results |
| 03_deterministic_validation | ot_vulnerability_gold_benchmark_15_cases.xlsx | 15-case gold set |
| 03_deterministic_validation | deterministic_benchmark_run_outputs.csv | Run predictions |
| 04_rag_agentic_evaluation | rag_agentic_gold_benchmark_22_queries.xlsx | 22-query gold set |
| 04_rag_agentic_evaluation | rag_agentic_run_outputs_supporting_text.csv | App run outputs |
| 04_rag_agentic_evaluation | rag_agentic_scoring_and_leakage_audit_pack.xlsx | Scoring workbook |
| 04_rag_agentic_evaluation | ragas_evaluation_results_final.csv | Per-query RAGAS scores |
| 04_rag_agentic_evaluation | ragas_eval.py | Scoring script |
| 05_supplementary_documentation | dataset_mapping_and_provenance_section.pdf | Provenance PDF |
| 05_supplementary_documentation | key_findings_input_output_comparison.docx | Findings summary |

---

## Contact / Questions

For questions about this package or the thesis, contact:

**Mohit Porwal**  
MSc Cybersecurity and Digital Forensics  
Liverpool John Moores University  
Student ID: [your student ID]  
Email: [your LJMU email]

**Supervisor:** [Supervisor name, LJMU]
